# Image-Processing
A collection of computer vision experiments and image processing algorithms implemented using Python and OpenCV. This repository includes intensity transformations, filtering, edge detection, histogram processing, and interpolation methods for academic and practical applications.
